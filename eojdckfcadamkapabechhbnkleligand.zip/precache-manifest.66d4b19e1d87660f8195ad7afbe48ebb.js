self.__precacheManifest = [
  {
    "revision": "2b08f984b492dea6445bcb2122f5ffff",
    "url": "/static/media/loc1.2b08f984.jpg"
  },
  {
    "revision": "e30f784fd6aa5301d2c5",
    "url": "/static/css/main.5afc3c86.chunk.css"
  },
  {
    "revision": "fdfcfda2d9b1bf31db52",
    "url": "/static/js/runtime~main.fdfcfda2.js"
  },
  {
    "revision": "b17a118e13e53558658b681a0ebdad82",
    "url": "/static/media/nucleo.b17a118e.ttf"
  },
  {
    "revision": "41e0220b21779bb07e22",
    "url": "/static/js/2.41e0220b.chunk.js"
  },
  {
    "revision": "666a282d26dab71bef2505cf35b2bdd5",
    "url": "/static/media/icon.666a282d.png"
  },
  {
    "revision": "e30f784fd6aa5301d2c5",
    "url": "/static/js/main.e30f784f.chunk.js"
  },
  {
    "revision": "5987dd12fea78ce5f97ae601b08ec03c",
    "url": "/static/media/nucleo.5987dd12.woff2"
  },
  {
    "revision": "f0b489a5dbbff08833d21024f9fcbd4e",
    "url": "/static/media/nucleo.f0b489a5.woff"
  },
  {
    "revision": "03ef1918e505c3e3471f9369ef7a638f",
    "url": "/static/media/nucleo.03ef1918.eot"
  },
  {
    "revision": "41e0220b21779bb07e22",
    "url": "/static/css/2.08ea857c.chunk.css"
  },
  {
    "revision": "fc70e1c329caf438a85d52a8e3879115",
    "url": "/index.html"
  }
];